# Smart Calculator — Capacitor Android APK

An advanced, feature-packed calculator ready for Android APK generation using **Capacitor** and **GitHub Actions**.

> **Package Name:** `com.smartcalculator.app`  
> **App Name:** `Smart Calc`  
> **Target Platform:** Android (Capacitor 8.x)  
> **Cloud Build:** Automated GitHub Actions (Debug APK artifact)  
> **Requirement:** 100% buildable from an **Android smartphone only** (no laptop/desktop needed).

---

## 📱 How to Build Your APK Using ONLY Your Android Smartphone

You do **not** need a laptop, Android Studio, or any desktop computer. GitHub's cloud servers will compile the APK for you completely free.

### Step 1: Download the Project ZIP to Your Phone
- Tap the **"Download Project (.ZIP)"** button in the app, or download `SmartCalculator-Android-Capacitor.zip` from your downloads.
- Keep it in your phone's **Downloads** folder.

---

### Step 2: Create a Free GitHub Repository on Your Phone
1. Open Chrome, Samsung Internet, or any mobile browser on your Android phone.
2. Go to [https://github.com](https://github.com) and log in (or create a free account).
3. In Chrome's menu (three dots in top right), check **"Desktop site"** (this gives you full access to all GitHub features on your phone).
4. Tap the **`+`** icon at top right and select **New repository**.
5. Fill in:
   - **Repository name:** `smart-calculator`
   - **Visibility:** **Public** (gives unlimited free GitHub Actions build minutes) or Private.
6. Tap **Create repository**.

---

### Step 3: Upload the Files to GitHub on Your Phone

#### Option A: Direct Web Upload (Simplest on Phone)
1. On your phone, open the **Files** or **My Files** app.
2. Find `SmartCalculator-Android-Capacitor.zip` and tap **Extract** to extract the folder.
3. In GitHub on your phone browser (in Desktop mode), tap the link: **"uploading an existing file"**.
4. Drag or select the extracted files (including `.github`, `android`, `src`, `package.json`, etc.) and tap **Commit changes**.

#### Option B: Using Termux on Android (Power User / 1 Command)
If you have **Termux** installed from F-Droid:
```bash
pkg update && pkg install git -y
cd /sdcard/Download
unzip SmartCalculator-Android-Capacitor.zip -d smartcalc
cd smartcalc
git init
git add .
git commit -m "Initial commit for Android APK"
git branch -M main
git remote add origin https://github.com/YOUR_GITHUB_USERNAME/smart-calculator.git
git push -u origin main
```

---

### Step 4: GitHub Actions Builds the APK Automatically in the Cloud
1. Once files are in your repository, tap the **Actions** tab at the top of your GitHub repository.
2. You will see a running workflow titled **"Build Android Debug APK"**.
3. Tap it to see real-time build progress.
   - It automatically sets up Node.js, builds the web assets, syncs Capacitor, configures JDK 17, and runs Gradle `./gradlew assembleDebug`.
4. The cloud build finishes in approximately **2 minutes**.

---

### Step 5: Download & Install the APK on Your Android Phone
1. When the workflow completes with a green checkmark `✔`, scroll down to the **Artifacts** section at the bottom of the page.
2. Tap **`SmartCalculator-debug-apk`**.
3. Your browser will download the ZIP containing your APK (`SmartCalculator-debug.apk`).
4. Tap the downloaded file in your Android notifications or Downloads folder.
5. If Android asks *"Allow installation from unknown sources"*, toggle it on for your browser or Files app.
6. Tap **Install**!
7. The **Smart Calc** app is now installed on your Android smartphone home screen with native performance!

---

## 🛠 Project Structure & Configuration

- **`capacitor.config.ts` & `capacitor.config.json`**:
  - `appId`: `com.smartcalculator.app`
  - `appName`: `Smart Calc`
  - `webDir`: `dist`
  - Native status bar and theme configuration
- **`android/`**: Full native Android project with:
  - `applicationId "com.smartcalculator.app"`
  - `gradlew` wrapper (pre-configured for JDK 17)
  - Pre-integrated Capacitor plugins:
    - `@capacitor/app` (hardware back button support)
    - `@capacitor/haptics` (vibration on button press)
    - `@capacitor/share` (native Android share sheet)
    - `@capacitor/status-bar` (dark/light system bar)
- **`.github/workflows/build-apk.yml`**: Cloud CI/CD workflow with `workflow_dispatch` (manual phone trigger) and automatic build on push.
- **`dist/` & `src/`**: Web application files with zero changes to your existing calculator features and design.

---

## 💡 Testing Without Installing an APK First
You can also run the web app in any mobile browser or "Add to Home screen" as a PWA directly while waiting for your APK build.
