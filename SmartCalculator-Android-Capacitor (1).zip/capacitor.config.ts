import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.smartcalculator.app',
  appName: 'Smart Calc',
  webDir: 'dist',
  android: {
    backgroundColor: '#0b0b0f',
    allowMixedContent: true,
    captureInput: true,
    webContentsDebuggingEnabled: true
  },
  server: {
    androidScheme: 'https'
  },
  plugins: {
    StatusBar: {
      style: 'DARK',
      backgroundColor: '#0b0b0f'
    }
  }
};

export default config;
