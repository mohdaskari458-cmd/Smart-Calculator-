import fs from 'fs';
import path from 'path';
import { ZipArchive } from 'archiver';

async function createZip() {
  const rootDir = process.cwd();
  const publicDir = path.join(rootDir, 'public');
  if (!fs.existsSync(publicDir)) {
    fs.mkdirSync(publicDir, { recursive: true });
  }

  const outputPaths = [
    path.join(rootDir, 'SmartCalculator-Android-Capacitor.zip'),
    path.join(publicDir, 'SmartCalculator-Android-Capacitor.zip')
  ];

  console.log('📦 Creating complete SmartCalculator Android Capacitor ZIP archive...');

  for (const zipPath of outputPaths) {
    const output = fs.createWriteStream(zipPath);
    const archive = new ZipArchive({
      zlib: { level: 9 }
    });

    await new Promise<void>((resolve, reject) => {
      output.on('close', () => {
        console.log(`✅ Saved ZIP (${(archive.pointer() / 1024 / 1024).toFixed(2)} MB) to: ${zipPath}`);
        resolve();
      });

      archive.on('error', (err: any) => {
        reject(err);
      });

      archive.pipe(output);

      // Add directories
      const dirsToAdd = ['.github', 'android', 'src', 'scripts'];
      for (const dir of dirsToAdd) {
        const fullDir = path.join(rootDir, dir);
        if (fs.existsSync(fullDir)) {
          archive.directory(fullDir, dir);
        }
      }

      // Add dist if it exists
      const distDir = path.join(rootDir, 'dist');
      if (fs.existsSync(distDir)) {
        archive.directory(distDir, 'dist');
      }

      // Add individual configuration and project files
      const filesToAdd = [
        'package.json',
        'package-lock.json',
        'capacitor.config.ts',
        'capacitor.config.json',
        'tsconfig.json',
        'vite.config.ts',
        'index.html',
        'metadata.json',
        'README.md',
        '.gitignore'
      ];

      for (const file of filesToAdd) {
        const fullFile = path.join(rootDir, file);
        if (fs.existsSync(fullFile)) {
          archive.file(fullFile, { name: file });
        }
      }

      archive.finalize();
    });
  }

  console.log('🎉 ZIP generation complete!');
}

createZip().catch((err) => {
  console.error('Error generating zip:', err);
  process.exit(1);
});
